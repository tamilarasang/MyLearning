package com.example.MyWebAppProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyWebAppProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyWebAppProjectApplication.class, args);
	}

}
